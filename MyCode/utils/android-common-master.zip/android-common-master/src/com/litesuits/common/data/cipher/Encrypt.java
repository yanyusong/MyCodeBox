package com.litesuits.common.data.cipher;

/**
 * @author MaTianyu
 * @date 14-7-31
 */
public interface Encrypt {
    public byte[] encrypt(byte[] res);
}
