package com.litesuits.common.data.cipher;

/**
 * @author MaTianyu
 * @date 14-7-31
 */
public interface Decrypt {
    public byte[] decrypt(byte[] res);
}
